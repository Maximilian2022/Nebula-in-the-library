//プリセットを登録
Virial.NebulaAPI.RegisterPreset("preset.damned.schrodinger","\"シュレディンガーの猫\"風 プリセット","他Modでみられる役職『シュレディンガーの猫』風のプリセット","options.role.schrodingersCat",()=>{
	//Damnedの追加役職定義を取得
	var damned = Virial.NebulaAPI.GetModifier("damned");
	//シュレディンガーの猫の役職定義を取得
	var cat = Virial.NebulaAPI.GetRole("schrodingersCat");
	
	//Damnedの役職フィルターを、"シュレディンガーの猫のみ"に設定
	damned.RoleFilter.Filter(Virial.Configuration.FilterAction.Set, cat);
	//キルを仕掛けた相手の役職を乗っ取る設定をOnに
	damned.GetConfiguration("options.role.damned.takeOverRoleOfKiller")?.UpdateValue(false);
	//キルを仕掛けた相手を殺す設定をOnに
	damned.GetConfiguration("options.role.damned.damnedMurderMyKiller")?.UpdateValue(false);
	//キルの遅延を15秒に設定
	damned.GetConfiguration("options.role.damned.killDelay")?.UpdateValue(15f);
	
	//Damnedがインポスター、クルーメイトに付与されないように
	damned.GetConfiguration("options.role.damned.impostorCount")?.UpdateValue(0);
	damned.GetConfiguration("options.role.damned.crewmateCount")?.UpdateValue(0);
	
	//Damnedが確率ではなく確実に割り当てられるように
	damned.GetConfiguration("options.role.damned.neutralRandomCount")?.UpdateValue(0);
	
	//Damnedとシュレディンガーの猫の人数を取得
	var damnedCount = damned.GetConfiguration("options.role.damned.neutralCount");
	int numOfDamned = damnedCount?.AsInt() ?? 0;
	var catCount = cat.GetConfiguration("options.role.schrodingersCat.count");
	int numOfCat = catCount?.AsInt() ?? 0;
	
	//1人以上はシュレディンガーの猫が湧くように
	if(numOfCat == 0){
		catCount?.UpdateValue(1);
		numOfCat = 1;
	}
	//全シュレディンガーの猫にDamnedが行き渡るように
	if(numOfCat > numOfDamned){
		damnedCount?.UpdateValue(numOfCat);
	}
});