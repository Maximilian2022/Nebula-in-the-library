using System;
using Virial;
using Virial.Game;
using Virial.Assignable;
using Virial.Attributes;
using Virial.Components;
using System.Collections.Generic;

public class SchrodingersCatDef : AbstractRoleDef
{
    //��E�͑�O�w�c�Ƃ��Ĕz�z�����
    public override RoleCategory RoleCategory => RoleCategory.NeutralRole;

    //�Ǝ��̐w�c������
    private Color MyColor;
    private RoleTeam MyTeam;
    public override RoleTeam Team => MyTeam;

    //��E�̎��ʗp�̖��O�ƐF�̐ݒ�
    public override string LocalizedName => "schrodingersCat";
    public override Color RoleColor =>  MyColor;


	public override IEnumerable<DefinedAssignable> RelatedAssignable(){
		yield return NebulaAPI.GetModifier("damned");
	}
	
    public SchrodingersCatDef()
    {
        MyColor = new Color(135, 168, 163);
        MyTeam = NebulaAPI.CreateTeam("team.schrodinger", MyColor, TeamRevealType.OnlyMe);
    }

    //��E��o�^����葱��
    [CallingRule(CallingEvent.PostRoles)]
    static public void PostRoles()
    {
        NebulaAPI.RegisterRole(new SchrodingersCatDef());
    }
}