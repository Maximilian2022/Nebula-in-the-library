using System;
using Virial;
using Virial.Game;
using Virial.Assignable;
using Virial.Attributes;
using Virial.Components;
using Virial.Events.Meeting;

public class NinjaDef : VariableRoleDef<NinjaInstance>
{
    public override RoleCategory RoleCategory => RoleCategory.ImpostorRole;
    public override RoleTeam Team => NebulaTeams.ImpostorTeam;
    
    public override string LocalizedName => "ninja";
    public override Color RoleColor => Color.ImpostorColor;
    
    [CallingRule(CallingEvent.PostRoles)]
    static public void PostRoles(){
        NebulaAPI.RegisterRole(new NinjaDef());
    }
}

public class NinjaInstance : AbstractRoleInstance<NinjaDef>
{
    AbilityButton boostButton;
    public override void OnActivated()
    {
        if(MyPlayer.AmOwner){
            boostButton = Bind(NebulaAPI.CreateAbilityButton());
            boostButton.SetLabel("boost");
            boostButton.SetImage(NebulaAPI.NebulaAsset.GetImage("Buttons.BoostButton",115f));
            boostButton.SetUpAsEffectButton(this, 20f, 10f, ()=>{
                MyPlayer.GainAttribute(PlayerAttribute.Invisible, 10f, false, 100);
                MyPlayer.GainAttribute(1.5f, 10f, false, 100);
            });
        }
    }
}